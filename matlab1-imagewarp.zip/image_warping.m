%% read image
im = imread('../TestImage/warp_test.bmp');

%% draw 2 copies of the image
figure('Units', 'pixel', 'Position', [100,100,1000,700], 'toolbar', 'none');
subplot(131); imshow(im); title({'Source image', 'Press the red tool button to add point-point constraints', 'Press the blue tool button to compute the RBFwarpped image'});
subplot(132); himg1 = imshow(im*0); title({'RBFWarpped Image'});
subplot(133); himg2 = imshow(im*0); title({'IDWWarpped Image'});
hToolPoint = uipushtool('CData', reshape(repmat([1 0 0], 100, 1), [10 10 3]), 'TooltipString', 'add point constraints to the map', ...
                        'ClickedCallback', @toolPositionCB, 'UserData', []);%CData:ͼ��
hToolWarp = uipushtool('CData', reshape(repmat([0 0 1], 100, 1), [10 10 3]), 'TooltipString', 'compute RBF and IDW warped image', ...
                       'ClickedCallback', @toolWarpCB);
%% TODO: implement function: RBFImageWarp and IDWImageWarp
% check the title above the image for how to use the simple user-interface to define point-constraints and compute the warpped image